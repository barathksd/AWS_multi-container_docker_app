# multi-container_docker_app
This contains a simple docker-based nginx and flask application which can be deployed to AWS using CI/CD pipeline
